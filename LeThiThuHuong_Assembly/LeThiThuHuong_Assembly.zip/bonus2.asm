bits 32
org 0x400000

; --- DOS HEADER ---
db 'MZ'                 ; Magic
times 60 db 0           ; Padding lấp đầy DOS Header
dd pe_header            ; Con trỏ tới PE Header (0x3C)

; --- GIẤU CODE VÀO ĐÂY (Vùng DOS Stub) ---
entry_point:            ; Đây là nơi ta sẽ trỏ EntryPoint tới
    xor eax, eax
    push eax            ; MB_OK
    push eax            ; Title NULL
    push eax            ; Text NULL
    push eax            ; hWnd NULL
    ; Gọi MessageBoxA thông qua địa chỉ trong bảng IAT (giấu trong Header)
    call [ebx]          
    ret

; --- PE HEADER ---
pe_header:
db 'PE', 0, 0           ; Signature
dw 0x014c               ; Machine (x86)
dw 0                    ; NumberOfSections = 0 (Để che giấu hoàn toàn các phân đoạn)
; ...
dd entry_point          ; Chỉnh AddressOfEntryPoint trỏ về vùng DOS Stub phía trên